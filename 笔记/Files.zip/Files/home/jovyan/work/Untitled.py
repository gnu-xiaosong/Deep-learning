#!/usr/bin/env python
# coding: utf-8

# In[2]:


try:
    get_ipython().system('jupyter nbconvert --to python 01.py')
except:
    pass


# In[ ]:




